#include<iostream>
using namespace std;
int main()
{
	int score1, score2, score3, score4, score5;
	cout << "Enter value for score1" << endl;
	cin>> score1;
	cout << "Enter value for score2" << endl;
	cin >> score2;
	cout << "Enter value for score3" << endl;
	cin >> score3;
	cout << "Enter value for score4" << endl;
	cin >> score4;
	cout << "Enter value for score5" << endl;
	cin >> score5;
	int average = score1 + score2 + score3 + score4 + score5 / 2;
	cout << Average is : ;
	return0;
}