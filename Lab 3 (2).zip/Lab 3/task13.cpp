#include<iostream>
using namespace std;
int main(){
    int Wheat,Rice,Sugar,quantity,price,value;
    cout<<"Enter price of Wheat:"<<endl;
    cin>>Wheat price;
    cout<<"Enter quantity of Wheat"<<endl;
    cin>>Wheat quantity;
    cout<<"Price of Rice:"<<endl;
    cin>>Rice price;
    cout<<"Enter quantity of Rice"<<endl;
    cin>>Rice quantity;
    cout<<"Enter price of sugar:"<<endl;
    cin>>Sugar price;
    cout<<"Enter quantity of sugar:"<<endl;
    cin>>Sugar quantity;
      float total Wheat=Wheat price*Wheat quantity;
      float total Rice=Rice price*Rice quantity;
      float total Sugar=Sugarprice*sugar quantity;
      cout<<"total Wheat;"<<total Wheat<<endl;
      cout<<"total Rice"<<total Rice<<endl;
      cout<<"total sugar"<<total sugar<<endl;
      return 0;
    }