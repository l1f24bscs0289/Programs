#include<iostream>
using namespace std;
int main()
{
	float radius, Area,;
	cout << "Enter value of radius:" << endl;
	cin << radius;
	float pi = 3.14;
	Area, A = pi(radius * radius);
	cout << "Area" << endl;
	return0;
}
	