#include<iostream>
using namespace std;
int main(){
    int Minutes,Hours;
    cout<<"Enter Minutes:"<<endl;
    cin>>Minutes;
    Hours=Minutes/60;
    Minutes=Minutes%60;
    cout<<Hours<<"Hours"<<Minutes<<"Minutes"<<endl;
    return 0;
    
}