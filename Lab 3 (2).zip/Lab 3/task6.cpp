#include<iostream>
using namespace std;
int main()
{
	cout << "Hello World" << endl;
	int x = 5;
	cout << "Value of x is:" << endl;
	return 0;

}