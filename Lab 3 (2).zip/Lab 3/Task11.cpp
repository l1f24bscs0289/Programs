#include<iostream>
using namespace std;
int main()
{
	int hours, minutes;
	cout << "Enter hours:" << endl;
	cin >> hours;
	cout << "Enter minutes:" << endl;
	cin >> minutes;
	minutes = hours * 60 + minutes;
	cout << "Total minutes" << minutes << endl;
	return 0;
}