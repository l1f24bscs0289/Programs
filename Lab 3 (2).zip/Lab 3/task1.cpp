
#include <iostream>
using namespace std;
int main() {
    int variable;
    cout << "Enter value for variable:"<<endl;
    cin >> variable;
    cout << "variable value entered:" << variable;
    return 0;
}