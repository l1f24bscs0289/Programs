#include<iostream>
using namespace std;
int main()
{
	int width, length;
	cout << "Enter value of width:" << endl;
	cin>> width;
	cout << "Enter value of length:" << endl;
	cin >> length;
	int Area = length * width;
	cout << "Area of rectangle:" << Area << endl;
	int Perimeter = 2 * (width + length);
	cout << "Perimeter of rectangle:" << Perimeter << endl;
	return 0;
}