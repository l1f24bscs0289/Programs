#include<iostream>
using namespace std;
int main(){
    int Chemistry,Maths,Physics;
    cout<<"Enter marks of Chemistry:"<<endl;
    cin>>Chemistry;
    cout<<"Enter marks in Maths:"<<endl;
    cin>>Maths;
    cout<<"Enter marks in Physics:"<<endl;
    cin>>Physics;
    cout<<"_____________________________________________________"<<endl;
    int Total=Chemistry+Maths+Physics;
    cout<<"Maths"<<"   "<<"Chemistry"<<"   "<<"Physics"<<"    "<<"Total"<<endl;
    cout<<Maths<<"          "<<Chemistry<<"       "<<Physics<<"         "<<Total<<endl;
    cout<<"_____________________________________________________"<<endl;
    return 0;
}

